export default class Move {
    constructor(guess,perfectMatch,partialMatch,message) {
        this.guess = guess;
        this.perfectMatch = perfectMatch;
        this.partialMatch = partialMatch;
        this.message = message;
    }

}